// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Class1.cs" company="Orcomp development team">
//   Copyright (c) 2012 - 2014 Orcomp development team. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------


namespace AnyProject
{
	public class Class1
	{
		#region Methods
		public void Method1()
		{
		}
		#endregion
	}
}