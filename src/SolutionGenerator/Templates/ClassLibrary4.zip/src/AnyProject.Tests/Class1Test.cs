// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Class1Test.cs" company="Orcomp development team">
//   Copyright (c) 2012 - 2014 Orcomp development team. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------


namespace AnyProject.Tests
{
	using NUnit.Framework;

	[TestFixture]
	public class Class1Test
	{
		[Test]
		public void TestMethod1()
		{
		}

	}
}