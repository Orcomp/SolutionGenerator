﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Program.cs" company="WildGums">
//   Copyright (c) 2008 - 2016 WildGums. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Data.Application
{
	using System;
	using System.Reflection;

	static class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine($"Data.Application.Console v{Assembly.GetExecutingAssembly().GetName().Version}\n");
			Console.WriteLine("See unit tests for a sample how to read data files.\n");
		}
	}
}