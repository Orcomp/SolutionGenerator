// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OperationX.cs" company="WildGums">
//   Copyright (c) 2008 - 2016 WildGums. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Data.Application
{
	public class OperationX
	{
		public string Id { get; set; }
		public string Name { get; set; }
		public string StartTime { get; set; }
		public string Duration { get; set; }
		public string Quantity { get; set; }
		public string Enabled { get; set; }
	}
}