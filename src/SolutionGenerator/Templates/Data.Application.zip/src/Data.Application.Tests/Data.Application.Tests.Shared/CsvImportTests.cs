﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OperationXTests.cs" company="WildGums">
//   Copyright (c) 2008 - 2016 WildGums. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Data.Application.Tests
{
	using System.IO;
	using Catel.IoC;
	using NUnit.Framework;
	using Orc.Csv;

	[TestFixture]
	public class CsvImportTests
	{
		private readonly string _testFilePath = Path.GetFullPath("TestFiles");

		[Test]
		public void ImportOperationX()
		{
			var serviceLocator = ServiceLocator.Default;
			var csvReaderService = serviceLocator.ResolveType<ICsvReaderService>();
			var result = csvReaderService.ReadCsv<OperationX>($"{_testFilePath}\\OperationX.csv", new OperationXMap());

			Assert.IsNotNull(result);
			// Change to the expected line count 
			// Assert.AreEqual(10000, result.Count());
		}
	}
}